<?php
var_dump($basket);