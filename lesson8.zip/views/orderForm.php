<div class="wrapperOrderForm">
    <form class="orderForm" action="/congratulate/index" method="post">
        <input type="text" name="tel" placeholder="Введите номер телефона">
        <input type="text" name="email" placeholder="Ваш email">
        <input class="orderForm__buy" type="submit" value="Оформить">
    </form>
</div>
