<div class="thanks">
    <div class="thanks__ok"> Спасибо! Ваш заказ успешно оформлен </div>
    <div class="thanks__text"> Наш менеджер связится с Вами для уточнения деталей оплаты и доставки товара </div>
</div>
