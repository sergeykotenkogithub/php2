<?php

namespace app\models\example;

class Product
{
    public $example;
    public $example1;
    public $example2;
}