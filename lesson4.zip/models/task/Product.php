<?php

namespace app\models\task;

abstract class Product
{
    public $originalPrice = 58;
    public static $total;
}

