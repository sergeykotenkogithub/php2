<?php


namespace app\models\entities;
use app\models\Model;
use app\models\repositories\UserRepository;


class Registration extends Model
{

}