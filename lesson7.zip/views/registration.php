<div class="registration">
    <?=$message?>
</div>
<div>
<? if (!$check): ?>
<div class="registration">
    Рады приветсвовать вас <?=$login?>
</div>
<?endif; ?>
</div>