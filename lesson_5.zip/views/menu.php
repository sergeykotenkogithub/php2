<div class="menu">
    <a href="/">Главная</a>
    <a href="/?c=product&a=catalog">Каталог</a>
    <a href="/?c=feedback&a=feedback">Отзывы</a>
    <a class="menu__basket" href="/?c=basket&a=basket"><img class="shopping" src="/img/icon/shopping_cart.svg" alt="shopping_cart"><span class="menu__span" >(0)</span></a>
</div>

