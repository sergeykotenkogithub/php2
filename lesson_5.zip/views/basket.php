Ожидается поставка товара

<?php var_dump($basket); ?>